import open3d as o3d
import os
import numpy as np
import glob

def write_velodyne_bin(out_path,out_points,filename):
    pl = out_points.reshape(-1, 4).astype(np.float32)
    velodyne_file_new = os.path.join(out_path,filename) + '.bin'
    pl.tofile(velodyne_file_new)

file_path = '/media/liyunchao/F/kitti_object_vis/velodyne_16_pcd/*.pcd'
file_dir = glob.glob(file_path)
file_dir.sort()

for i in zip(file_dir):
    points_pcd = o3d.io.read_point_cloud(i[0])
    points_F = np.asarray(points_pcd.points)
    points_F_list=points_F.tolist()
    b=np.ones(len(points_F_list))


    points_F=np.c_[points_F,b]


    out_path = '/data/KITTI/object/training/velodyne16_ng_bin'
    write_velodyne_bin(out_path,points_F,i[0][-10:-4])
    print(i[0][-10:-4]+" has saved")
    #exit()