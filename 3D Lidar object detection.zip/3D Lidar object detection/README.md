
## Dataset Setup
Download KITTI Object Detection Dataset and organize as:
```
kitti/object/
├── training/
│   ├── calib/
│   ├── image_2/
│   ├── label_2/
│   └── velodyne/
```

## Quick Install
```bash
conda create -n kitti_vis python=3.7
conda activate kitti_vis
pip install opencv-python pillow scipy matplotlib
conda install mayavi -c conda-forge
```

## Usage
```bash
# Basic visualization
python kitti_object.py --vis --show_lidar_with_depth --img_fov

# Point cloud processing
python PointCloudDeNoising.py
python bin2pcd.py
```

## Core Files
- `kitti_object.py` - Main visualization script
- `kitti_util.py` - Utility functions  
- `PointCloudDeNoising.py` - Point cloud processing
- `viz_util.py` - Visualization helpers

For remote installation, see `jupyter/` folder.