import struct
import numpy as np
import os
import math
import glob

#import open3d as o3d


# 功能： 从kitti的.bin格式点云文件中读取点云
# 输入： path：文件路径
# 输出： 点云数组

def read_velodyne_bin(path):
    pc_list=[]
    with open(path,'rb') as f:
        content = f.read()
        pc_iter = struct.iter_unpack('ffff',content)
        for idx,point in enumerate(pc_iter):
            pc_list.append([point[0],point[1],point[2],point[3]])
    #return np.asarray(pc_list,dtype=np.float32)
    return pc_list


def points2pcd(points,out_path):
    # 存放路径
    PCD_DIR_PATH = os.path.join(os.path.abspath('.'), 'fogpoints-mid_pcd')
    #PCD_DIR_PATH = os.path.join(os.path.abspath('.'), 'velodyne_pcd')
    PCD_FILE_PATH = os.path.join(PCD_DIR_PATH, out_path +'.pcd')
    if os.path.exists(PCD_FILE_PATH):
        os.remove(PCD_FILE_PATH)

    # 写文件句柄
    handle = open(PCD_FILE_PATH, 'a')

    # 得到点云点数
    point_num = points.shape[0]

    # pcd头部（重要）
    handle.write(
        '# .PCD v0.7 - Point Cloud Data file format\nVERSION 0.7\nFIELDS x y z i\nSIZE 4 4 4 4\nTYPE F F F F\nCOUNT 1 1 1 1')
    string = '\nWIDTH ' + str(point_num)
    handle.write(string)
    handle.write('\nHEIGHT 1\nVIEWPOINT 0 0 0 1 0 0 0')
    string = '\nPOINTS ' + str(point_num)
    handle.write(string)
    handle.write('\nDATA ascii')
    # 依次写入点
    for i in range(point_num):
        string = '\n' + str(points[i, 0]) + ' ' + str(points[i, 1]) + ' ' + str(points[i, 2]) + ' ' + str(points[i, 3])
        handle.write(string)
    handle.close()

if __name__== '__main__':

    file_path = '/data/KITTI/object/training/fogpoints-mid/*.bin'
    file_dir = glob.glob(file_path)
    file_dir.sort()

    for i in zip(file_dir):
        #print(i[0])
        points = read_velodyne_bin(i[0])
        #print("points:",points)
        points = np.asarray(points, dtype=np.float32)
        #print(i[0][-10:-4])
        points2pcd(points, i[0][-10:-4])
        print(i[0][-10:-4],'is save')
        #exit()