import struct

import numpy as np
import os
import math
import glob
#import open3d as o3d


def read_velodyne_bin(path):
    pc_list=[]
    with open(path,'rb') as f:
        content = f.read()
        pc_iter = struct.iter_unpack('ffff',content)
        for idx,point in enumerate(pc_iter):
            pc_list.append([point[0],point[1],point[2],point[3]])
    #return np.asarray(pc_list,dtype=np.float32)
    return pc_list


def write_velodyne_bin(out_path,out_points,filename):
    pl = out_points.reshape(-1, 4).astype(np.float32)
    velodyne_file_new = os.path.join(out_path,filename) + '.bin'
    pl.tofile(velodyne_file_new)


def kitti_64_to_16(points):
    x_lidar=points[:,0]
    y_lidar=points[:,1]
    
    x_radians=np.arctan2(y_lidar,x_lidar)

    angle_diff = np.abs(np.diff(x_radians))

    threshold_angle = np.radians(250)
    angle_diff = np.hstack((angle_diff,0.0001))
    angle_diff_mask = angle_diff > threshold_angle

    change_point = np.argwhere(angle_diff_mask).flatten()
    change_point_adjusted = [int((change_point[i]+change_point[i+1])/2) for i in range (len(change_point)-1)]


    angle_diff_mask = np.zeros(len(angle_diff_mask))
    angle_diff_mask[change_point_adjusted] = 1

    y_img = np.cumsum(angle_diff_mask)

    indices_16=y_img%4==0
    points_16=points[indices_16,:]

    return points_16

if __name__== '__main__':


    file_path_T = '/data/KITTI/object/training/velodynedenoising/*.bin'
    file_dir_T = glob.glob(file_path_T)



    file_path_F = '/data/KITTI/object/training/F-points/*.bin'
    file_dir_F = glob.glob(file_path_F)
    file_dir_T.sort()
    file_dir_F.sort()


    for i,j in zip(file_dir_T,file_dir_F):

        points_T = read_velodyne_bin(i)
        points_F = read_velodyne_bin(j)

   
        points_all=points_F+points_T
        points_all = np.asarray(points_all, dtype=np.float32)

        out_path = '/data/KITTI/object/training/pointL+C'
        write_velodyne_bin(out_path,points_all,i[-10:-4])
        print(i[-10:-4]+" has saved")






