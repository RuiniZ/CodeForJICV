
import open3d as o3d
import copy
import glob
import mayavi.mlab
import struct
import os
import math
import torch
import numpy as np

import mayavi.mlab
import torch
import numpy as np



def getDistanceBetweenTwoPoints(p1, p2):
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1])  ** 2 + (p1[2] - p2[2]) ** 2)


def write_velodyne_bin(out_path,out_points,filename):
    pl = out_points.reshape(-1, 4).astype(np.float32)
    velodyne_file_new = os.path.join(out_path,filename) + '.bin'
    pl.tofile(velodyne_file_new)

def read_velodyne_bin(path):
    pc_list=[]
    with open(path,'rb') as f:
        content = f.read()
        pc_iter = struct.iter_unpack('ffff',content)
        for idx,point in enumerate(pc_iter):
            d = math.sqrt((float(point[0])) ** 2 + (float(point[1])) ** 2)
            pc_list.append([point[0],point[1],point[2],point[3],d])
    return pc_list


def points2pcd(points,out_path):

    PCD_DIR_PATH = os.path.join(os.path.abspath('.'), 'fogpoint_pcd')
    PCD_FILE_PATH = os.path.join(PCD_DIR_PATH, out_path +'.pcd')
    if os.path.exists(PCD_FILE_PATH):
        os.remove(PCD_FILE_PATH)

    handle = open(PCD_FILE_PATH, 'a')


    point_num = points.shape[0]

   
    handle.write(
        '# .PCD v0.7 - Point Cloud Data file format\nVERSION 0.7\nFIELDS x y z i\nSIZE 4 4 4 4\nTYPE F F F F\nCOUNT 1 1 1 1')
    string = '\nWIDTH ' + str(point_num)
    handle.write(string)
    handle.write('\nHEIGHT 1\nVIEWPOINT 0 0 0 1 0 0 0')
    string = '\nPOINTS ' + str(point_num)
    handle.write(string)
    handle.write('\nDATA ascii')
 
    for i in range(point_num):
        string = '\n' + str(points[i, 0]) + ' ' + str(points[i, 1]) + ' ' + str(points[i, 2]) + ' ' + str(points[i, 3])
        handle.write(string)
    handle.close()

def viz_mayavi(points,vals="height"):  
    x=points[:,0]
    y=points[:,1]
    z=points[:,2]
    d=torch.sqrt(x**2+y**2)

    if vals=="height":
        col=z
    else:
        col=d

    fig=mayavi.mlab.figure(bgcolor=(0,0,0),size=(1280,720))
    mayavi.mlab.points3d(x,y,z,
                         col,
                         mode="point",
                         colormap='spectral',
                         figure=fig,
                         )

    mayavi.mlab.show()


if __name__== '__main__':

    pointcloud = read_velodyne_bin(file_path)
    print(pointcloud)
    print(len(pointcloud))

    rightpoints = []
    errpoints = []
    for point in pointcloud:
        if point[4] < 10:
            if point[3] < (30 * 5 * 5 / (point[4] ** 2)):
                errpoints.append(point[0:4])
            else:
                rightpoints.append(point[0:4])
        else:
            if point[3] < (10 * 5 * 5 / (point[4] ** 2)):
                errpoints.append(point[0:4])
            else:
                rightpoints.append(point[0:4])

    pointcloud = np.asarray(rightpoints, dtype=np.float32)

    mypointcloud = torch.from_numpy(pointcloud)
    viz_mayavi(mypointcloud, vals="height")




