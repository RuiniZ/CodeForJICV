
import struct
import mayavi.mlab
import torch
import numpy as np
import math
import os

def read_velodyne_bin(path):
    pc_list=[]
    with open(path,'rb') as f:
        content = f.read()
        pc_iter = struct.iter_unpack('ffff',content)
        for idx,point in enumerate(pc_iter):
            pc_list.append([point[0],point[1],point[2]])
    return pc_list

def show_pointcloud(points,vals="distance"):
    x = points[:, 0]
    y = points[:, 1]
    z = points[:, 2]
    d = torch.sqrt(x ** 2 + y ** 2)
    if vals == "height":
        col = z
    else:
        col = d
    fig = mayavi.mlab.figure(bgcolor=(0, 0, 0), size=(1280, 720))
    mayavi.mlab.points3d(x, y, z,
                         col,
                         mode="point",
                         colormap='spectral',
                         figure=fig,
                         )
    mayavi.mlab.show()

def pointcloud_filter(points,distance,count):
    points_filter=[]
    for i in range (len(points)):
        c=0
        for j in range (len(points)):
            if abs(points[i][0] - points[j][0]) > distance or abs(points[i][1] - points[j][1]) > distance or abs(points[i][2] - points[j][2]) > distance:
                continue
            d=math.sqrt((float(points[i][0])-float(points[j][0]))**2+(float(points[i][1])-float(points[j][1]))**2+(float(points[i][2])-float(points[j][2]))**2)
            if d<distance:
                c=c+1
            if c>count:
                #print(points[i])
                points_filter.append(points[i])
                break
    return points_filter

if __name__== '__main__':
    file_path_F = '/results/sdn_kitti_train_set/pseudo_lidar_trainval_sparse/000000.bin'
    points_F = read_velodyne_bin(file_path_F)
    print(points_F)
    points_filter=pointcloud_filter(points_F, distance=1, count=10)
    points_F = np.asarray(points_filter, dtype=np.float32)
    points_F = torch.from_numpy(points_F)
    #print(points_F)
    show_pointcloud(points_F, vals="height")

