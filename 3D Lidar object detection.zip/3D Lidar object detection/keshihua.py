
import mayavi.mlab
import torch
import numpy as np
import math



print(pointcloud)
rightpoints = []
errpoints = []
for point in pointcloud:
    d=math.sqrt((float(point[0])) ** 2 + (float(point[1])) ** 2)
    if d <3 and d >0:
        if point[4] < (200/ (d**2)):
            errpoints.append(point[0:5])
        elif point[2]<2:
            rightpoints.append(point[0:5])
    elif d >3 and d <4:
        if point[4] < (100/ (d**2)):
            errpoints.append(point[0:5])
        elif point[2]<2:
            rightpoints.append(point[0:5])
    elif  d >4 and d <6:
        if point[4] < (1000/ (d**2)):
            errpoints.append(point[0:5])
        elif point[2]<2:
            rightpoints.append(point[0:5])
    elif  d >6:
        if point[4] < (2000/ (d**2)):
            errpoints.append(point[0:5])
        elif point[2]<2:
            rightpoints.append(point[0:5])
rightpoints=np.array(rightpoints)
mypointcloud=torch.from_numpy(rightpoints)

print(mypointcloud.size())
print(mypointcloud.type())

def viz_mayavi(points,vals="distance"): 
    x=points[:,0]
    y=points[:,1]
    z=points[:,2]
    d=torch.sqrt(x**2+y**2)

    if vals=="height":
        col=z
    else:
        col=d

    fig=mayavi.mlab.figure(bgcolor=(0,0,0),size=(1280,720))
    mayavi.mlab.points3d(x,y,z,
                         col,
                         mode="point",
                         colormap='spectral',
                         figure=fig,
                         )

    mayavi.mlab.show()

if __name__=="__main__":
    viz_mayavi(mypointcloud,vals="height")


