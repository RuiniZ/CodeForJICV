
import numpy as np
import open3d as o3d
import math
import copy
import glob
import os

def define_area(plane_points):

    point1 = np.asarray(plane_points[0])
    point2 = np.asarray(plane_points[1])
    point3 = np.asarray(plane_points[2])
    AB = np.asmatrix(point2 - point1)
    AC = np.asmatrix(point3 - point1)
    N = np.cross(AB, AC) 
    Ax = N[0, 0]
    By = N[0, 1]
    Cz = N[0, 2]
    D = -(Ax * point1[0] + By * point1[1] + Cz * point1[2])
    return Ax, By, Cz, D

def l_and_plane_point(p1,p2,plane_points):
    a, b, c, d = define_area(plane_points)
    plane_normal = np.array([a, b, c])  
    P1D = (np.vdot(p1, plane_normal) + d) / np.sqrt(np.vdot(plane_normal, plane_normal))
    P1D2 = (np.vdot(p2 - p1, plane_normal)) / np.sqrt(np.vdot(plane_normal, plane_normal))
    n = P1D2 / P1D
    p = p1 + n * (p2 - p1)
    return(p)


def isThreePointsInSameLine(p1, p2, p3):
    distance12 = getDistanceBetweenTwoPoints(p1, p2)
    distance23 = getDistanceBetweenTwoPoints(p2, p3)
    distance13 = getDistanceBetweenTwoPoints(p1, p3)


    p12X = math.fabs((p1[0] - p2[0]) / distance12)
    p12Y = math.fabs((p1[1] - p2[1]) / distance12)
    p12Z = math.fabs((p1[2] - p2[2]) / distance12)


    p23X = math.fabs((p2[0] - p3[0]) / distance23)
    p23Y = math.fabs((p2[1] - p3[1]) / distance23)
    p23Z = math.fabs((p2[2] - p3[2]) / distance23)


    p13X = math.fabs((p1[0] - p3[0]) / distance13)
    p13Y = math.fabs((p1[1] - p3[1]) / distance13)
    p13Z = math.fabs((p1[2] - p3[2]) / distance13)

    err = 0.3  
    if isInRange(p12X, p23X, err) and isInRange(p12Y, p23Y, err) and isInRange(p12Z,p23Z,err):
        if isInRange(p12X, p13X, err) and isInRange(p12Y, p13Y, err) and isInRange(p12Z,p13Z,err):
            return True
    return False


def getDistanceBetweenTwoPoints(p1, p2):
    return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1])  ** 2 + (p1[2] - p2[2]) ** 2)


def isInRange(A, B, error):
    if A - error <= B <= A + error:
        return True
    else:
        return False

def point2area_distance(points, p):

    Ax, By, Cz, D = define_area(points)
    mod_d = Ax * p[0] + By * p[1] + Cz * p[2] + D
    mod_area = np.sqrt(np.sum(np.square([Ax, By, Cz])))
    d = abs(mod_d) / mod_area
    return d


def touying(points, p):
    out_point=[]
    A, B, C, D = define_area(points)
    t=(A*p[0]+B*p[1]+C*p[2])/(A**2+B**2+C**2)
    x=p[0]-A*t
    y=p[1]-B*t
    z=p[2]-C*t
    out_point.append(x)
    out_point.append(y)
    out_point.append(z)
    return np.asarray(out_point)


def write_velodyne_bin(out_path,out_points,filename):
    pl = out_points.reshape(-1, 4).astype(np.float32)
    velodyne_file_new = os.path.join(out_path,filename) + '.bin'
    pl.tofile(velodyne_file_new)


if __name__== '__main__':

    file_dir_T.sort()
    file_dir_F.sort()

    for i, j in zip(file_dir_T, file_dir_F):

        pcd_t = o3d.io.read_point_cloud(i)
        pcd_f = o3d.io.read_point_cloud(j)
        n1=len(pcd_t.points)
        output_points=[]
        num=len(pcd_f.points)

        for n in range (num):
            pcd_t1 =copy.deepcopy(pcd_t)
            n1=len(pcd_t1.points)
            np_points_t=np.asarray(pcd_t1.points)
            np_points_f= np.asarray(pcd_f.points[n])
            np_points=np.append([np_points_f], np_points_t, axis=0)
            pcd_t1.points = o3d.utility.Vector3dVector(np_points)
            n2=len(pcd_t1.points)



            point_1 = np.asarray(pcd_f.points[n])
            point_0 = np.asarray([0, 0, 0])


            pcd_tree = o3d.geometry.KDTreeFlann(pcd_t1)
            if np.all(pcd_f.points[n]==pcd_t1.points[0]):
                [k, idx, _] = pcd_tree.search_knn_vector_3d(pcd_t1.points[0], 4)
                points=np.asarray(pcd_t1.points)[idx[1:], :]
                if len(points)<3:
                    output_points.append(point_1)
                else:
                    #print(points)
                    p1=points[0]
                    p2=points[1]
                    p3=points[2]
                    distance1 = getDistanceBetweenTwoPoints(point_1, p1)
                    distance2 = getDistanceBetweenTwoPoints(point_1, p2)
                    distance3 = getDistanceBetweenTwoPoints(point_1, p3)

                    if distance1 < 0.5 and distance2 < 0.5 and distance3 < 0.5 :
                        if isThreePointsInSameLine(p1, p2, p3) is True:
                            outpoint=[]
                            outpoint_x = (p1[0] + p2[0] + p3[0]) / 3
                            outpoint_y = (p1[1] + p2[1] + p3[1]) / 3
                            outpoint_z = point_1[2]
                            outpoint.append(outpoint_x)
                            outpoint.append(outpoint_y)
                            outpoint.append(outpoint_z)
                            output_points.append(outpoint)

                        else:
                            outpoint=l_and_plane_point(point_1, point_0, points)
                            d1=getDistanceBetweenTwoPoints(outpoint, point_1)
                            d2=point2area_distance(points, outpoint)
                            if d1<d2 and d1 <0.3:
                                output_points.append(outpoint)
                            else:
                                outpoint=touying(points, point_1)
                                d3=getDistanceBetweenTwoPoints(outpoint, point_1)
                                if d3<0.3:
                                    output_points.append(outpoint)
                                else:
                                    output_points.append(point_1)
                    else:
                        output_points.append(point_1)

        Outpoints = np.asarray(output_points,dtype=np.float32)
        b = np.ones(len(Outpoints))
        Outpoints = np.c_[Outpoints, b]


        out_path = '/media/liyunchao/F/kitti_object_vis/FT_velodyne1'
        write_velodyne_bin(out_path,Outpoints,i[-10:-4])
        print(i[-10:-4]+" has saved")
        exit()




