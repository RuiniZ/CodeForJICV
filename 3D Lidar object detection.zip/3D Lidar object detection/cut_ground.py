import struct
import mayavi.mlab
import torch
import numpy as np
import os
import math
import glob

#import open3d as o3d



def read_velodyne_bin(path):
    pc_list=[]
    with open(path,'rb') as f:
        content = f.read()
        pc_iter = struct.iter_unpack('ffff',content)
        for idx,point in enumerate(pc_iter):
            pc_list.append([point[0],point[1],point[2],point[3]])
    #return np.asarray(pc_list,dtype=np.float32)
    return pc_list


def write_velodyne_bin(out_path,out_points,filename):
    pl = out_points.reshape(-1, 4).astype(np.float32)
    velodyne_file_new = os.path.join(out_path,filename) + '.bin'
    pl.tofile(velodyne_file_new)


def get_plane_by_lsq(data):
    A = np.hstack((data,np.ones((data.shape[0],1),dtype=np.float64)))
    AtA = np.matmul(A.T,A)
    U,S,V_H = np.linalg.svd(AtA)
    plane = U[:,-1]/np.linalg.norm(U[0:3,-1])
    return plane


def get_inner_idx(points,plane,threshold):
    N = points.shape[0]
    data = np.hstack((points,np.ones((N,1),dtype=np.float32)))
    distance = abs(np.matmul(data,plane)) / np.linalg.norm(plane[0:3])
    return distance<threshold


def get_inner(points,plane,threshold):
    idx = get_inner_idx(points,plane,threshold)
    return points[idx]


def get_inner_num(inner_points):
    return inner_points.shape[0]


def calculate_max_iter(p,inner_ratio,sample_num):
    max_iter = int(np.ceil(1.2*np.log(1-p)/np.log(1-inner_ratio**sample_num)))
    return max_iter


def get_plane_by_ransac(points,threshold,max_iter,max_inner_rate):
    N = points.shape[0]
    max_inner_num = np.floor(N*max_inner_rate) 
    inner_max_num = 0
    plane = np.zeros((4,1),dtype=float)
    for i in range(max_iter):
        random_idx = np.random.choice(np.arange(N),size=3,replace=False) 
        sample_points = points[random_idx,:]
        sample_plane=get_plane_by_lsq(sample_points)
        inner_points = get_inner(points,sample_plane,threshold)
        inner_num = get_inner_num(inner_points)
        if inner_num > max_inner_num:
            plane = get_plane_by_lsq(inner_points)
            break
        if inner_num > inner_max_num:
            plane = get_plane_by_lsq(inner_points)
            inner_max_num = inner_num
        continue
    inner_idx= get_inner_idx(points,plane,threshold)
    inner_points = get_inner(points,plane,threshold)
    plane = get_plane_by_lsq(inner_points)
    return plane, inner_idx,inner_points


def pointcloud_not_ground(points,inner_idx):
    inner_idx = np.array(inner_idx)
    not_ground_idx = (inner_idx == False)
    not_ground_points = points[not_ground_idx]
    return not_ground_points


def show_pointcloud(points,vals="distance"):
    x = points[:, 0]
    y = points[:, 1]
    z = points[:, 2]
    d = torch.sqrt(x ** 2 + y ** 2)
    if vals == "height":
        col = z
    else:
        col = d
    fig = mayavi.mlab.figure(bgcolor=(0, 0, 0), size=(1280, 720))
    mayavi.mlab.points3d(x, y, z,
                         col,
                         mode="point",
                         colormap='spectral',
                         figure=fig,
                         )
    mayavi.mlab.show()


def pointcloud_filter(points,distance,count):
    #print(points)
    points_filter=[]
    for i in range (len(points)):
        c=0
        for j in range (len(points)):
            if abs(points[i][0] - points[j][0]) > distance or abs(points[i][1] - points[j][1]) > distance or abs(points[i][2] - points[j][2]) > distance:
                continue
            d=math.sqrt((float(points[i][0])-float(points[j][0]))**2+(float(points[i][1])-float(points[j][1]))**2+(float(points[i][2])-float(points[j][2]))**2)
            if d<distance:
                c=c+1
            if c>count:
                #print(points[i])
                points_filter.append(points[i])
                break
    return points_filter


def kitti_64_to_16(points):
    x_lidar=points[:,0]
    y_lidar=points[:,1]
    x_radians=np.arctan2(y_lidar,x_lidar)

    angle_diff = np.abs(np.diff(x_radians))

    threshold_angle = np.radians(250)
    angle_diff = np.hstack((angle_diff,0.0001))
    angle_diff_mask = angle_diff > threshold_angle

    change_point = np.argwhere(angle_diff_mask).flatten()
    change_point_adjusted = [int((change_point[i]+change_point[i+1])/2) for i in range (len(change_point)-1)]


    angle_diff_mask = np.zeros(len(angle_diff_mask))
    angle_diff_mask[change_point_adjusted] = 1

    y_img = np.cumsum(angle_diff_mask)

    indices_16=y_img%4==0
    points_16=points[indices_16,:]

    return points_16


def points2pcd(points,out_path):
    #PCD_DIR_PATH = os.path.join(os.path.abspath('.'), 'F_velodyne_pcd')
    PCD_DIR_PATH = os.path.join(os.path.abspath('.'), 'velodyne_16_pcd')
    PCD_FILE_PATH = os.path.join(PCD_DIR_PATH, out_path +'.pcd')
    if os.path.exists(PCD_FILE_PATH):
        os.remove(PCD_FILE_PATH)


    handle = open(PCD_FILE_PATH, 'a')


    point_num = points.shape[0]

    handle.write(
        '# .PCD v0.7 - Point Cloud Data file format\nVERSION 0.7\nFIELDS x y z i\nSIZE 4 4 4 4\nTYPE F F F F\nCOUNT 1 1 1 1')
    string = '\nWIDTH ' + str(point_num)
    handle.write(string)
    handle.write('\nHEIGHT 1\nVIEWPOINT 0 0 0 1 0 0 0')
    string = '\nPOINTS ' + str(point_num)
    handle.write(string)
    handle.write('\nDATA ascii')
    for i in range(point_num):
        string = '\n' + str(points[i, 0]) + ' ' + str(points[i, 1]) + ' ' + str(points[i, 2]) + ' ' + str(points[i, 3])
        handle.write(string)
    handle.close()
if __name__== '__main__':

    p=0.99               
    inner_ratio=0.5    
    max_inner_rate=0.8*inner_ratio  
    sample_num=100   
    threshold_T=0.1      
    threshold_F=0.1


    file_path_T = '/data/KITTI/object/training/point16_t+ft/*.bin'
    file_dir_T = glob.glob(file_path_T)
    #points_T = read_velodyne_bin(file_path_T)
    #print("points_T:", points_T)

    file_path_F = '/data/KITTI/object/training/velodyne_F_notground/*.bin'
    file_dir_F = glob.glob(file_path_F)
    file_dir_T.sort()
    file_dir_F.sort()


    for i,j in zip(file_dir_T,file_dir_F):

        points_T = read_velodyne_bin(i)
        points_T = np.asarray(points_T, dtype=np.float32)


        points_F = read_velodyne_bin(j)



        points_filter_t = torch.from_numpy(points_T)

        show_pointcloud(points_filter_t, vals="hnizheeight")






